import { useState, useEffect } from "react";
import "../styles/BeginningSounds.css";

// 🔥 Firebase
import { db } from "../firebase";
import { doc, collection, addDoc, Timestamp } from "firebase/firestore";

export default function SoundMatching() {

  const TOTAL_QUESTIONS = 5;

  const [currentSound, setCurrentSound] = useState("");
  const [options, setOptions] = useState([]);

  const [score, setScore] = useState(0);
  const [questionCount, setQuestionCount] = useState(0);

  const [feedback, setFeedback] = useState("");
  const [loading, setLoading] = useState(true);

  // 🤖 AI QUESTION
  const generateQuestionAI = async () => {
    try {
      setLoading(true);

      const res = await fetch("http://localhost:5000/api/generate-sound-matching", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        }
      });

      const data = await res.json();

      console.log("AI DATA:", data);

      if (!data.sound || !data.options) {
        throw new Error("Invalid data");
      }

      setCurrentSound(data.sound);
      setOptions(data.options);

    } catch (err) {
      console.error(err);

      // fallback
      setCurrentSound("B");
      setOptions([
        { word: "Ball", sound: "B", emoji: "⚽" },
        { word: "Cat", sound: "C", emoji: "🐱" },
        { word: "Dog", sound: "D", emoji: "🐶" },
        { word: "Sun", sound: "S", emoji: "☀️" }
      ]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    generateQuestionAI();
  }, []);

  // ☁️ SAVE
  const saveScoreToFirestore = async (finalScore) => {
    try {
      const userEmail = "demo_user";

      const userRef = doc(db, "users", userEmail);
      const gameResultsRef = collection(userRef, "game_results");

      const accuracy = (finalScore / TOTAL_QUESTIONS) * 100;

      await addDoc(gameResultsRef, {
        score: finalScore,
        totalQuestions: TOTAL_QUESTIONS,
        accuracy: accuracy.toFixed(2),
        createdAt: Timestamp.now(),
        game: "SoundMatching_AI"
      });

    } catch (error) {
      console.error(error);
    }
  };

  // 🎯 HANDLE CLICK
  const handleClick = (item) => {

    if (questionCount >= TOTAL_QUESTIONS) return;

    const isCorrect = item.sound === currentSound;
    const updatedScore = isCorrect ? score + 1 : score;

    if (isCorrect) {
      setScore(updatedScore);
      setFeedback("correct");
    } else {
      setFeedback("wrong");
    }

    setTimeout(async () => {

      setFeedback("");

      const nextCount = questionCount + 1;
      setQuestionCount(nextCount);

      if (nextCount === TOTAL_QUESTIONS) {

        await saveScoreToFirestore(updatedScore);

        alert(`🎯 Round Completed!\nScore: ${updatedScore}/${TOTAL_QUESTIONS}`);

        setScore(0);
        setQuestionCount(0);
        generateQuestionAI();

      } else {
        generateQuestionAI();
      }

    }, 700);
  };

  // 📊 ANALYSIS
  const getPerformanceMessage = () => {
    if (questionCount === 0) return "";

    const accuracy = (score / questionCount) * 100;

    if (accuracy > 80) return "🌟 Excellent!";
    if (accuracy > 50) return "👍 Good job!";
    return "💡 Practice more!";
  };

  return (
    <div className="phonics-page">

      <div className="letter-navbar">
        <h2>🤖 AI Sound Matching</h2>
      </div>

      <div className="game-info">
        <span>Question: {questionCount + 1}/{TOTAL_QUESTIONS}</span>
        <span>Score: {score}</span>
      </div>

      <h3>Which word starts with:</h3>

      <div className="big-letter">
        {loading ? "..." : `/ ${currentSound} /`}
      </div>

      <div className="options-grid">
        {loading ? (
          <p>Loading...</p>
        ) : (
          options.map((item, index) => (
            <button
              key={index}
              className="option-btn"
              onClick={() => handleClick(item)}
            >
              {item.emoji} {item.word}
            </button>
          ))
        )}
      </div>

      {feedback === "correct" && (
        <div className="feedback good">🎉 Correct!</div>
      )}

      {feedback === "wrong" && (
        <div className="feedback wrong">❌ Try Again</div>
      )}

      <div className="ai-analysis">
        <p>{getPerformanceMessage()}</p>
      </div>

    </div>
  );
}